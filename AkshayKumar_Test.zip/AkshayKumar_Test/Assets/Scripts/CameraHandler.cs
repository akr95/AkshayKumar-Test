﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraHandler : MonoBehaviour
{

	#region public varaibles.
	public GameObject Target;    // hold player(Target) refernece.
	#endregion

	#region private varaibles.
	private Vector3 offset;     // hold offset value between target and camera.
	#endregion


	// Start is called before the first frame update
	void Start()
	{
		// take offset value.
		offset = transform.position - Target.transform.position;
	}

	// Update is called once per frame
	void LateUpdate()
	{
		// update camera position in between camera and target.
		transform.position = Target.transform.position + offset;
	}
}