﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreHandler : MonoBehaviour
{

	#region public - static variables 
	public static int score;
	public static int streak = 1;
	#endregion

	#region private variables.
	private Text scoreText;
	#endregion


	// Start is called before the first frame update
	void Awake()
	{
		scoreText = GetComponent<Text>();
	}

	// Update is called once per frame
	void Update()
	{
		if (EnumHandler.gameStatus == EnumHandler.GameStatus.Play)
		{
			Debug.Log(score);
			scoreText.text = "Score : " + score + "\nStreak : " + streak;
		}
	}


}
