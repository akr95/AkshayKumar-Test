﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerHandler : MonoBehaviour
{
	#region public variables.
	public InfoScriptableObject infoScriptableObject;
	public float speed;  // control player speed.
	#endregion

	#region private varaibles.
	string lastCollideBall;
	Rigidbody rb;  // store rigidbody refernce.
	#endregion

	// Start is called before the first frame update
	void Start()
	{
		rb = GetComponent<Rigidbody>();

	}

	// Update is called once per frame
	void FixedUpdate()
	{
		if (EnumHandler.gameStatus == EnumHandler.GameStatus.Play)
		{
			float horizontal = Input.GetAxis("Horizontal");
			float vertical = Input.GetAxis("Vertical");

			Vector3 vector3 = new Vector3(horizontal, 0, vertical);

			rb.AddForce(vector3 * speed, ForceMode.Acceleration);
		}
	}


	private void OnCollisionEnter(Collision collision)
	{
		Debug.Log(collision.gameObject.name);
		ObjectProperties objectProperties = infoScriptableObject.objectProperties.Find(item => item.name.ToLower() == collision.gameObject.name.ToLower());

		if (objectProperties != null)
		{
			ScoreCalculate(objectProperties);
			Destroy(collision.gameObject);

		}
		objectProperties = null;
	}


	void ScoreCalculate(ObjectProperties properties)
	{
		if (lastCollideBall == properties.name.ToLower())
		{
			ScoreHandler.streak++;
		}
		else
		{
			lastCollideBall = properties.name.ToLower();
			ScoreHandler.streak = 1;
		}
		ScoreHandler.score += properties.points * ScoreHandler.streak;
		Debug.Log(ScoreHandler.score);
	}
}
