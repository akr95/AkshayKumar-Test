﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ObjectProperties
{
	public string name;
	public Color color;
	public int points;
}

[CreateAssetMenu(fileName = "CubeInfo", menuName = "WizAr/Create Cube Info", order = 1)]
public class InfoScriptableObject : ScriptableObject
{

	public List<ObjectProperties> objectProperties;

}
