﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnumHandler : MonoBehaviour
{

	#region public and static variables.
	public enum GameStatus { None, Play, Pause, Stop };
	public static GameStatus gameStatus;
	#endregion


	void Awake()
	{
		gameStatus = GameStatus.None;
	}

}
