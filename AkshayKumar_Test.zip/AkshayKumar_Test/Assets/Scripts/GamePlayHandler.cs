﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Analytics;

public class GamePlayHandler : MonoBehaviour
{
	#region public variables.
	public GameObject cubes;
	public Text startTimerText, gamePlayTimerText;
	public int startTimer = 3;
	public int gamePlayTimer = 60;
	#endregion


	void Awake()
	{
		startTimerText.text = startTimer.ToString();
		gamePlayTimerText.text = "Timer : " + gamePlayTimer.ToString();
		StartCoroutine(StartTImer(startTimer));
	}

	// Update is called once per frame
	void Update()
	{
		if (EnumHandler.gameStatus == EnumHandler.GameStatus.Play)
		{
			if (cubes.transform.childCount <= 0)
			{
				GameOver();
			}
		}
	}


	IEnumerator StartTImer(int value)
	{
		yield return new WaitForSeconds(1f);
		startTimerText.text = value.ToString();
		if (value <= 0)
		{
			startTimerText.text = "";
			// Start game 
			EnumHandler.gameStatus = EnumHandler.GameStatus.Play;
			StartCoroutine(GameTimer(gamePlayTimer));
		}
		else
		{
			value--;
			StartCoroutine(StartTImer(value));
		}

	}


	IEnumerator GameTimer(int value)
	{
		yield return new WaitForSeconds(1);
		if (EnumHandler.gameStatus == EnumHandler.GameStatus.Play)
		{
			gamePlayTimerText.text = "Timer : " + value.ToString();
			if (value <= 0)
			{
				gamePlayTimerText.text = "Timer : 0";
				// Game Over
				GameOver();
			}
			else
			{
				value--;
				StartCoroutine(GameTimer(value));
			}
		}
		else
		{
			yield return null;
		}
	}

	public void GameOver()
	{
		startTimerText.text = "Congratulations you gained " + ScoreHandler.score + " scores";
		EnumHandler.gameStatus = EnumHandler.GameStatus.Stop;
		if ((PlayerPrefs.GetInt("BestScore", 0)) < ScoreHandler.score)
		{
			PlayerPrefs.SetInt("BestScore", ScoreHandler.score);
		}
	}


}
