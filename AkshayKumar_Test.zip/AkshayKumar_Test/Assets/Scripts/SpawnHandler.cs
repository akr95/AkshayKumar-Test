﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnHandler : MonoBehaviour
{

	#region PUBLIC VARAIBLES.
	public float posX, negX, posZ, negZ;
	public GameObject cubePrefabs, cubeParents;
	public InfoScriptableObject infoScriptableObject;
	public int spawnLength = 10;
	#endregion

	#region private variables.
	List<Transform> spawnRandomPosition;
	ObjectProperties objectProperties;
	#endregion


	// Start is called before the first frame update
	void Start()
	{
		spawnRandomPosition = new List<Transform>();
		SpawnCubeInPlane();

	}

	// Update is called once per frame
	void Update()
	{


	}

	void SpawnCubeInPlane()
	{
		for (int i = 0; i < spawnLength; i++)
		{
			objectProperties = infoScriptableObject.objectProperties[Random.Range(0, infoScriptableObject.objectProperties.Count)];

			float randomX = Random.Range(negX, posX);
			float randomZ = Random.Range(negZ, posZ);
			Vector3 randomPosition = new Vector3(randomX, 0, randomZ);

			GameObject spawnObject = Instantiate(cubePrefabs, cubeParents.transform, true);
			spawnObject.transform.localPosition = randomPosition;
			spawnObject.GetComponent<MeshRenderer>().material.color = objectProperties.color;
			spawnObject.name = objectProperties.name;

		}
	}



}
