﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverHandler : MonoBehaviour
{

	#region Public Varibales.
	public Text gameOverText;
	public static GameOverHandler instance;
	#endregion


	// Start is called before the first frame update
	void Start()
	{
		instance = this;
	}

	// Update is called once per frame
	void Update()
	{

	}


	public void GameOver()
	{
		EnumHandler.gameStatus = EnumHandler.GameStatus.Stop;

	}

}
